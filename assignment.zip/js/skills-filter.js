/**
 * SKILLS & DSA FILTER COMPONENT — PROTTOY ROY
 * Handles category filtering and real-time live search across all technical skillsets.
 */

export function initSkillsFilter() {
  const filterButtons = document.querySelectorAll('.filter-btn');
  const searchInput = document.getElementById('skills-search-input');
  const categoryBlocks = document.querySelectorAll('.skill-category-block');
  const allChips = document.querySelectorAll('.skill-chip');

  let activeCategory = 'all';
  let searchTerm = '';

  function applyFilters() {
    categoryBlocks.forEach((block) => {
      const blockCategory = block.getAttribute('data-category');
      const chipsInBlock = block.querySelectorAll('.skill-chip');
      let visibleChipsInBlock = 0;

      const categoryMatches = activeCategory === 'all' || activeCategory === blockCategory;

      chipsInBlock.forEach((chip) => {
        const chipName = (chip.getAttribute('data-name') || chip.textContent).toLowerCase();
        const matchesSearch = searchTerm === '' || chipName.includes(searchTerm);

        if (categoryMatches && matchesSearch) {
          chip.style.display = 'inline-flex';
          visibleChipsInBlock++;
          if (searchTerm !== '') {
            chip.style.borderColor = 'var(--accent-primary)';
            chip.style.backgroundColor = 'rgba(16, 185, 129, 0.08)';
          } else {
            chip.style.borderColor = '';
            chip.style.backgroundColor = '';
          }
        } else {
          chip.style.display = 'none';
        }
      });

      // Show or hide the entire category block based on matches
      if (categoryMatches && visibleChipsInBlock > 0) {
        block.style.display = 'block';
        const countBadge = block.querySelector('.category-badge-count');
        if (countBadge) {
          countBadge.textContent = `${visibleChipsInBlock} items`;
        }
      } else {
        block.style.display = 'none';
      }
    });
  }

  // Filter Button Clicks
  filterButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterButtons.forEach((b) => {
        b.classList.remove('active');
        b.setAttribute('aria-pressed', 'false');
      });

      btn.classList.add('active');
      btn.setAttribute('aria-pressed', 'true');
      activeCategory = btn.getAttribute('data-filter') || 'all';
      applyFilters();
    });
  });

  // Search Input Handler
  searchInput?.addEventListener('input', (e) => {
    searchTerm = e.target.value.trim().toLowerCase();
    applyFilters();
  });
}
