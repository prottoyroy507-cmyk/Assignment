/**
 * INTERACTIVE ALGORITHM NETWORK VISUALIZER — PROTTOY ROY
 * HTML5 Canvas rendering dynamic algorithmic nodes and data structures.
 * Supports mouse repulsion, physics dampening, and reduced-motion fallback.
 */

export function initAlgorithmCanvas() {
  const canvas = document.getElementById('ps-algorithm-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  let width = (canvas.width = canvas.parentElement.clientWidth);
  let height = (canvas.height = canvas.parentElement.clientHeight || 380);

  // Responsive DPI scaling
  function resize() {
    if (!canvas.parentElement) return;
    const dpr = window.devicePixelRatio || 1;
    width = canvas.parentElement.clientWidth;
    height = Math.max(300, canvas.parentElement.clientHeight || 380);

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
  }

  window.addEventListener('resize', resize, { passive: true });
  resize();

  // Algorithmic Nodes Representation
  const NODE_LABELS = [
    { label: "BST: O(log N)", type: "tree", radius: 8 },
    { label: "Binary Search", type: "search", radius: 7 },
    { label: "AVL Balanced", type: "tree", radius: 8 },
    { label: "Sliding Window", type: "two-pointer", radius: 7 },
    { label: "Min-Heap", type: "heap", radius: 7 },
    { label: "Map: O(1)", type: "hash", radius: 6 },
    { label: "Recursion Stack", type: "stack", radius: 6 },
    { label: "Frequency Vector", type: "array", radius: 6 },
    { label: "Queue / BFS", type: "queue", radius: 6 },
    { label: "Sorting: O(N log N)", type: "sort", radius: 7 }
  ];

  const nodes = NODE_LABELS.map((item, idx) => {
    return {
      label: item.label,
      type: item.type,
      x: (width * 0.15) + Math.random() * (width * 0.7),
      y: (height * 0.15) + Math.random() * (height * 0.7),
      vx: (Math.random() - 0.5) * 0.6,
      vy: (Math.random() - 0.5) * 0.6,
      baseRadius: item.radius,
      radius: item.radius,
      pulse: Math.random() * Math.PI * 2,
      pulseSpeed: 0.03 + Math.random() * 0.02
    };
  });

  // Track Mouse Interaction
  const mouse = {
    x: -9999,
    y: -9999,
    radius: 120,
    isHovered: false
  };

  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
    mouse.isHovered = true;
  });

  canvas.addEventListener('mouseleave', () => {
    mouse.x = -9999;
    mouse.y = -9999;
    mouse.isHovered = false;
  });

  // Touch Support
  canvas.addEventListener('touchmove', (e) => {
    if (e.touches.length > 0) {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.touches[0].clientX - rect.left;
      mouse.y = e.touches[0].clientY - rect.top;
      mouse.isHovered = true;
    }
  }, { passive: true });

  canvas.addEventListener('touchend', () => {
    mouse.x = -9999;
    mouse.y = -9999;
    mouse.isHovered = false;
  });

  let animationFrameId;

  function render() {
    ctx.clearRect(0, 0, width, height);

    // 1. Draw subtle connecting algorithmic edges
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 140) {
          const alpha = (1 - dist / 140) * 0.28;
          ctx.beginPath();
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          ctx.strokeStyle = `rgba(16, 185, 129, ${alpha})`;
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }
      }
    }

    // 2. Update & Draw Nodes
    nodes.forEach((node) => {
      if (!prefersReducedMotion) {
        // Subtle drift
        node.x += node.vx;
        node.y += node.vy;

        // Bounce off canvas boundaries
        if (node.x <= 20 || node.x >= width - 20) node.vx *= -1;
        if (node.y <= 20 || node.y >= height - 20) node.vy *= -1;

        // Mouse repulsion physics
        const dx = node.x - mouse.x;
        const dy = node.y - mouse.y;
        const distToMouse = Math.sqrt(dx * dx + dy * dy);

        if (distToMouse < mouse.radius) {
          const force = (1 - distToMouse / mouse.radius) * 1.8;
          const angle = Math.atan2(dy, dx);
          node.x += Math.cos(angle) * force;
          node.y += Math.sin(angle) * force;
        }

        // Pulse animation
        node.pulse += node.pulseSpeed;
      }

      const isNearMouse = Math.hypot(node.x - mouse.x, node.y - mouse.y) < 65;
      const currentRadius = isNearMouse ? node.baseRadius + 2.5 : node.baseRadius;

      // Glow halo on hover
      if (isNearMouse) {
        ctx.beginPath();
        ctx.arc(node.x, node.y, currentRadius * 2.8, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(16, 185, 129, 0.15)';
        ctx.fill();
      }

      // Outer ring
      ctx.beginPath();
      ctx.arc(node.x, node.y, currentRadius, 0, Math.PI * 2);
      ctx.fillStyle = isNearMouse ? '#10b981' : '#0e1726';
      ctx.fill();
      ctx.strokeStyle = isNearMouse ? '#f8fafc' : '#10b981';
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Center core
      ctx.beginPath();
      ctx.arc(node.x, node.y, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = isNearMouse ? '#07090e' : '#38bdf8';
      ctx.fill();

      // Node Label Text
      ctx.font = isNearMouse ? '600 11px "JetBrains Mono", monospace' : '500 10px "JetBrains Mono", monospace';
      ctx.fillStyle = isNearMouse ? '#f8fafc' : '#94a3b8';
      ctx.fillText(node.label, node.x + currentRadius + 8, node.y + 3);
    });

    if (!prefersReducedMotion) {
      animationFrameId = requestAnimationFrame(render);
    }
  }

  render();

  // Cleanup reference
  return () => {
    if (animationFrameId) cancelAnimationFrame(animationFrameId);
    window.removeEventListener('resize', resize);
  };
}
