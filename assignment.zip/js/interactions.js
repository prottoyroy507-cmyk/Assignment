/**
 * INTERACTIVE UTILITIES & UI CONTROLS — PROTTOY ROY PORTFOLIO
 * Features animated stat counters, clipboard copy with toasts, project schema modal,
 * and client-side contact composer.
 */

import { PORTFOLIO_DATA } from './data.js';

export function initInteractions() {
  initStatCounters();
  initClipboardToast();
  initProjectModal();
  initContactComposer();
  initBackToTop();
}

/**
 * 1. Animated Stat Counters with IntersectionObserver
 */
function initStatCounters() {
  const statElements = document.querySelectorAll('.stat-number[data-target]');
  if (!statElements.length) return;

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.getAttribute('data-target'), 10);
        const suffix = el.getAttribute('data-suffix') || '';
        animateValue(el, 0, target, 1200, suffix);
        obs.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  statElements.forEach((el) => observer.observe(el));
}

function animateValue(el, start, end, duration, suffix = '') {
  let startTimestamp = null;
  const step = (timestamp) => {
    if (!startTimestamp) startTimestamp = timestamp;
    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
    // Ease out cubic
    const easedProgress = 1 - Math.pow(1 - progress, 3);
    const currentVal = Math.floor(easedProgress * (end - start) + start);
    el.innerHTML = `${currentVal}<span class="stat-accent">${suffix}</span>`;
    if (progress < 1) {
      window.requestAnimationFrame(step);
    } else {
      el.innerHTML = `${end}<span class="stat-accent">${suffix}</span>`;
    }
  };
  window.requestAnimationFrame(step);
}

/**
 * 2. Toast Notification & Copy to Clipboard
 */
export function showToast(message) {
  let toastContainer = document.querySelector('.toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.className = 'toast-container';
    toastContainer.setAttribute('role', 'status');
    toastContainer.setAttribute('aria-live', 'polite');
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
    <span>${message}</span>
  `;

  toastContainer.appendChild(toast);

  // Trigger animation
  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 3200);
}

function initClipboardToast() {
  const copyButtons = document.querySelectorAll('[data-copy-text]');
  copyButtons.forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      const textToCopy = btn.getAttribute('data-copy-text');
      if (!textToCopy) return;

      try {
        await navigator.clipboard.writeText(textToCopy);
        showToast(`Copied to clipboard: ${textToCopy}`);
      } catch (err) {
        // Fallback
        showToast(`Text to copy: ${textToCopy}`);
      }
    });
  });
}

/**
 * 3. Project Details & Relational Schema Modal
 */
function initProjectModal() {
  const modalBackdrop = document.getElementById('project-modal');
  const modalCloseBtn = document.getElementById('modal-close-btn');
  const modalTitle = document.getElementById('modal-project-title');
  const modalCategory = document.getElementById('modal-project-category');
  const modalDesc = document.getElementById('modal-project-desc');
  const modalSchemaContainer = document.getElementById('modal-schema-content');
  const modalActions = document.getElementById('modal-project-actions');
  const triggerBtns = document.querySelectorAll('[data-project-details]');

  function openModal(projectId) {
    const project = PORTFOLIO_DATA.projects.find((p) => p.id === projectId);
    if (!project || !modalBackdrop) return;

    if (modalTitle) modalTitle.textContent = project.title;
    if (modalCategory) modalCategory.textContent = project.category;
    if (modalDesc) modalDesc.textContent = project.description;

    // Build Relational Schema Representation
    if (modalSchemaContainer) {
      if (project.schemaBreakdown && project.schemaBreakdown.length > 0) {
        let schemaHtml = `
          <div style="font-family: var(--font-mono); margin-top: var(--space-md);">
            <div style="font-size: 0.75rem; color: var(--accent-primary); text-transform: uppercase; margin-bottom: 8px; letter-spacing: 0.08em; font-weight: 600;">
              Relational Schema & Architecture Blueprint
            </div>
            <div style="display: flex; flex-direction: column; gap: 8px;">
        `;

        project.schemaBreakdown.forEach((item) => {
          schemaHtml += `
            <div style="background: var(--bg-tertiary); padding: 10px 14px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
              <div style="color: var(--accent-cyan); font-weight: 600; font-size: 0.82rem; margin-bottom: 2px;">
                TABLE: ${item.table}
              </div>
              <div style="color: var(--text-secondary); font-size: 0.75rem;">
                ${item.cols}
              </div>
            </div>
          `;
        });

        schemaHtml += `</div></div>`;
        modalSchemaContainer.innerHTML = schemaHtml;
      } else {
        modalSchemaContainer.innerHTML = '';
      }
    }

    // Modal Actions
    if (modalActions) {
      modalActions.innerHTML = `
        <a href="${project.githubUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm">
          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path>
          </svg>
          GitHub Repository
        </a>
      `;
    }

    modalBackdrop.classList.add('open');
    modalBackdrop.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    modalCloseBtn?.focus();
  }

  function closeModal() {
    if (!modalBackdrop) return;
    modalBackdrop.classList.remove('open');
    modalBackdrop.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  triggerBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const projectId = btn.getAttribute('data-project-details');
      if (projectId) openModal(projectId);
    });
  });

  modalCloseBtn?.addEventListener('click', closeModal);

  modalBackdrop?.addEventListener('click', (e) => {
    if (e.target === modalBackdrop) closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalBackdrop?.classList.contains('open')) {
      closeModal();
    }
  });
}

/**
 * 4. Client-Side Contact Message Composer
 */
function initContactComposer() {
  const form = document.getElementById('contact-composer-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const nameInput = document.getElementById('sender-name');
    const emailInput = document.getElementById('sender-email');
    const messageInput = document.getElementById('sender-message');

    const name = nameInput?.value.trim() || 'Colleague';
    const senderEmail = emailInput?.value.trim() || '';
    const message = messageInput?.value.trim() || '';

    const subject = encodeURIComponent(`Portfolio Inquiry from ${name}`);
    const body = encodeURIComponent(
      `Hello Prottoy,\n\n${message}\n\nFrom: ${name}\nEmail: ${senderEmail}`
    );

    // Direct mailto trigger
    const mailtoUrl = `mailto:${PORTFOLIO_DATA.profile.emailPlaceholder}?subject=${subject}&body=${body}`;
    showToast('Opening default email client...');
    window.location.href = mailtoUrl;
  });
}

/**
 * 5. Back to Top Button
 */
function initBackToTop() {
  const backToTopBtn = document.getElementById('back-to-top-btn');
  backToTopBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
}
