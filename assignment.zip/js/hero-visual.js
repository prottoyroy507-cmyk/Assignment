/**
 * HERO INTERACTIVE WORKSPACE COMPONENT — PROTTOY ROY
 * Provides an authentic code editor simulator with syntax-highlighted tabs and simulated runtime inspects.
 */

const SNIPPETS = {
  java: {
    filename: "FurnitureApp.java",
    language: "Java",
    output: "⚡ [JDBC] Connected to MariaDB 'furniture_db' @ localhost:3306. Query executed: 24 active items loaded. UI initialized.",
    code: `<span class="code-kw">public class</span> <span class="code-type">FurnitureApp</span> {
    <span class="code-kw">private</span> <span class="code-type">Connection</span> conn;

    <span class="code-kw">public void</span> <span class="code-fn">initDatabase</span>() <span class="code-kw">throws</span> <span class="code-type">SQLException</span> {
        <span class="code-type">String</span> url = <span class="code-str">"jdbc:mariadb://localhost:3306/furniture_db"</span>;
        <span class="code-kw">this</span>.conn = <span class="code-type">DriverManager</span>.<span class="code-fn">getConnection</span>(url, <span class="code-str">"prottoy"</span>, <span class="code-str">"***"</span>);
        <span class="code-type">System</span>.out.<span class="code-fn">println</span>(<span class="code-str">"✓ Relational DB connected successfully."</span>);
    }

    <span class="code-kw">public void</span> <span class="code-fn">launchGUI</span>() {
        <span class="code-type">SwingUtilities</span>.<span class="code-fn">invokeLater</span>(() -&gt; <span class="code-kw">new</span> <span class="code-type">MainDashboardFrame</span>(conn).<span class="code-fn">setVisible</span>(<span class="code-kw">true</span>));
    }
}`
  },

  sql: {
    filename: "RelationalSchema.sql",
    language: "SQL",
    output: "⚡ [MariaDB Engine] Schema validated: 4 tables verified with referential integrity (FK constraints OK).",
    code: `<span class="code-cmt">-- Prottoy Furniture Factory Management System Schema</span>
<span class="code-kw">CREATE TABLE</span> <span class="code-type">customers</span> (
    customer_id <span class="code-type">INT AUTO_INCREMENT PRIMARY KEY</span>,
    full_name <span class="code-type">VARCHAR(100) NOT NULL</span>,
    phone <span class="code-type">VARCHAR(20) NOT NULL</span>,
    address <span class="code-type">TEXT</span>
);

<span class="code-kw">CREATE TABLE</span> <span class="code-type">orders</span> (
    order_id <span class="code-type">INT AUTO_INCREMENT PRIMARY KEY</span>,
    customer_id <span class="code-type">INT NOT NULL</span>,
    order_date <span class="code-type">DATETIME DEFAULT CURRENT_TIMESTAMP</span>,
    total_amount <span class="code-type">DECIMAL(10,2) NOT NULL</span>,
    <span class="code-kw">FOREIGN KEY</span> (customer_id) <span class="code-kw">REFERENCES</span> <span class="code-type">customers</span>(customer_id)
);`
  },

  cpp: {
    filename: "BinarySearchTree.cpp",
    language: "C++",
    output: "⚡ [C++20 Compiler] Compiled with 0 warnings. Inorder: [14, 25, 36, 48, 62, 75, 91]. Search(48) -> Found in O(log N).",
    code: `<span class="code-kw">template</span> &lt;<span class="code-kw">typename</span> <span class="code-type">T</span>&gt;
<span class="code-kw">struct</span> <span class="code-type">TreeNode</span> {
    <span class="code-type">T</span> val;
    <span class="code-type">TreeNode</span>* left = <span class="code-kw">nullptr</span>;
    <span class="code-type">TreeNode</span>* right = <span class="code-kw">nullptr</span>;
    <span class="code-fn">TreeNode</span>(<span class="code-type">T</span> x) : val(x) {}
};

<span class="code-kw">bool</span> <span class="code-fn">searchBST</span>(<span class="code-type">TreeNode</span>&lt;<span class="code-type">int</span>&gt;* root, <span class="code-type">int</span> target) {
    <span class="code-kw">if</span> (!root) <span class="code-kw">return false</span>;
    <span class="code-kw">if</span> (root-&gt;val == target) <span class="code-kw">return true</span>;
    <span class="code-kw">return</span> (target &lt; root-&gt;val) ? <span class="code-fn">searchBST</span>(root-&gt;left, target) 
                                 : <span class="code-fn">searchBST</span>(root-&gt;right, target);
}`
  },

  json: {
    filename: "DeveloperSpec.json",
    language: "JSON",
    output: "⚡ [Spec Validator] Identity verified: Software Engineering Student • Metropolitan University (Grad: 2029).",
    code: `{
  <span class="code-str">"name"</span>: <span class="code-str">"Prottoy Roy"</span>,
  <span class="code-str">"institution"</span>: <span class="code-str">"Metropolitan University"</span>,
  <span class="code-str">"degree"</span>: <span class="code-str">"B.Sc. (Hons) in Software Engineering"</span>,
  <span class="code-str">"current_stage"</span>: <span class="code-str">"2nd Year, 3rd Semester"</span>,
  <span class="code-str">"graduation"</span>: <span class="code-num">2029</span>,
  <span class="code-str">"core_focus"</span>: [<span class="code-str">"Problem Solving"</span>, <span class="code-str">"Software Development"</span>, <span class="code-str">"App Dev"</span>],
  <span class="code-str">"location"</span>: <span class="code-str">"Bangladesh"</span>
}`
  }
};

export function initHeroWorkspace() {
  const tabs = document.querySelectorAll('.hero-tab-btn');
  const codeDisplay = document.getElementById('hero-code-display');
  const outputDisplay = document.getElementById('hero-output-text');
  const runBtn = document.getElementById('hero-run-btn');
  const statusLang = document.getElementById('hero-status-lang');
  const statusFile = document.getElementById('hero-status-file');

  let currentKey = 'java';

  function switchTab(key) {
    if (!SNIPPETS[key]) return;
    currentKey = key;
    const snippet = SNIPPETS[key];

    // Update active tab styles
    tabs.forEach((tab) => {
      const tabKey = tab.getAttribute('data-tab');
      if (tabKey === key) {
        tab.classList.add('active');
        tab.setAttribute('aria-selected', 'true');
      } else {
        tab.classList.remove('active');
        tab.setAttribute('aria-selected', 'false');
      }
    });

    // Update code & language indicators
    if (codeDisplay) {
      codeDisplay.innerHTML = `<pre><code>${snippet.code}</code></pre>`;
    }
    if (statusLang) statusLang.textContent = snippet.language;
    if (statusFile) statusFile.textContent = snippet.filename;
    if (outputDisplay) {
      outputDisplay.innerHTML = `<span style="opacity: 0.6;">Ready to execute ${snippet.filename}. Click 'Run / Inspect'</span>`;
    }
  }

  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      const key = tab.getAttribute('data-tab');
      if (key) switchTab(key);
    });
  });

  runBtn?.addEventListener('click', () => {
    const snippet = SNIPPETS[currentKey];
    if (!snippet || !outputDisplay) return;

    outputDisplay.innerHTML = `<span style="color: var(--accent-amber);">▶ Executing ${snippet.filename}...</span>`;

    setTimeout(() => {
      outputDisplay.innerHTML = snippet.output;
    }, 280);
  });

  // Default initialize with Java
  switchTab('java');
}
