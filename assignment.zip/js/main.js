/**
 * MAIN ENTRY POINT — PROTTOY ROY PORTFOLIO
 * Orchestrates modular architecture and component lifecycles.
 */

import { initNavigation } from './navigation.js';
import { initHeroWorkspace } from './hero-visual.js';
import { initAlgorithmCanvas } from './canvas-graph.js';
import { initSkillsFilter } from './skills-filter.js';
import { initInteractions } from './interactions.js';

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Core Navigation
  initNavigation();

  // Initialize Hero Interactive Developer Workspace
  initHeroWorkspace();

  // Initialize Algorithm & DSA Interactive Canvas
  initAlgorithmCanvas();

  // Initialize Skills Filter & Live Search
  initSkillsFilter();

  // Initialize Interactions (Stats, Toast, Modal, Message Composer)
  initInteractions();

  // Console Branding Signature
  console.log(
    `%c PROTTOY ROY %c Software Engineering Student | Problem Solver | Aspiring App Developer `,
    'background: #10b981; color: #07090e; font-weight: bold; padding: 4px 8px; border-radius: 4px 0 0 4px;',
    'background: #0d1118; color: #f8fafc; padding: 4px 8px; border-radius: 0 4px 4px 0; border: 1px solid #10b981;'
  );
});
