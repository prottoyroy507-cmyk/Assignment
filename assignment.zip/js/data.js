/**
 * PORTFOLIO DATA REPOSITORY — PROTTOY ROY
 * Cleanly separated data layer for easy maintenance and future updates.
 */

export const PORTFOLIO_DATA = {
  profile: {
    name: "Prottoy Roy",
    tagline: "Software Engineering Student | Problem Solver | Aspiring App Developer",
    shortBio: "I’m a Software Engineering student at Metropolitan University, passionate about problem solving, software development, and building practical applications that solve real-world problems.",
    university: "Metropolitan University",
    degree: "B.Sc. (Hons) in Software Engineering",
    academicStatus: "2nd Year, 3rd Semester",
    expectedGraduation: "2029",
    location: "Bangladesh",
    emailPlaceholder: "[YOUR EMAIL]",
    socials: {
      github: "https://github.com/[YOUR_GITHUB_USERNAME]",
      linkedin: "https://linkedin.com/in/[YOUR_LINKEDIN_USERNAME]",
      codeforces: "https://codeforces.com/profile/[YOUR_CODEFORCES_HANDLE]"
    }
  },

  interests: [
    "Software Development",
    "Mobile Application Development",
    "Problem Solving",
    "Database Systems",
    "Data Structures & Algorithms",
    "Building Real-World Applications"
  ],

  skills: {
    programming: [
      { name: "C", category: "Programming" },
      { name: "C++", category: "Programming" },
      { name: "Java", category: "Programming" },
      { name: "Python", category: "Programming" }
    ],
    database: [
      { name: "SQL", category: "Database" },
      { name: "MariaDB", category: "Database" },
      { name: "JDBC", category: "Database" }
    ],
    dsa: [
      { name: "Arrays", category: "Data Structures & Algorithms" },
      { name: "Strings", category: "Data Structures & Algorithms" },
      { name: "Vector", category: "Data Structures & Algorithms" },
      { name: "Set", category: "Data Structures & Algorithms" },
      { name: "Map", category: "Data Structures & Algorithms" },
      { name: "Stack", category: "Data Structures & Algorithms" },
      { name: "Queue", category: "Data Structures & Algorithms" },
      { name: "Binary Tree", category: "Data Structures & Algorithms" },
      { name: "BST (Binary Search Tree)", category: "Data Structures & Algorithms" },
      { name: "AVL Tree", category: "Data Structures & Algorithms" },
      { name: "Heap", category: "Data Structures & Algorithms" },
      { name: "Sorting", category: "Data Structures & Algorithms" },
      { name: "Searching", category: "Data Structures & Algorithms" },
      { name: "Binary Search", category: "Data Structures & Algorithms" },
      { name: "Recursion", category: "Data Structures & Algorithms" },
      { name: "Sliding Window", category: "Data Structures & Algorithms" },
      { name: "Frequency Counting", category: "Data Structures & Algorithms" }
    ],
    tools: [
      { name: "Java GUI", category: "Development / Tools" },
      { name: "Database Applications", category: "Development / Tools" },
      { name: "GitHub", category: "Development / Tools" },
      { name: "VS Code", category: "Development / Tools" },
      { name: "Vercel", category: "Development / Tools" }
    ],
    exploring: [
      { name: "Flutter", category: "Currently Exploring" },
      { name: "Dart", category: "Currently Exploring" },
      { name: "React Native", category: "Currently Exploring" },
      { name: "Mobile Application Development", category: "Currently Exploring" }
    ]
  },

  projects: [
    {
      id: "prottoy-furniture",
      number: "01",
      title: "Prottoy Furniture",
      category: "Database / Software Application",
      status: "Completed",
      statusBadgeClass: "badge-emerald",
      technologies: ["Java", "JDBC", "MariaDB", "SQL"],
      description: "A comprehensive furniture factory and shop management application designed to manage customers, furniture inventory, orders, and order items using a structured relational database with robust JDBC connectivity.",
      highlights: [
        "Customer entity and profile management",
        "Furniture inventory tracking and classification",
        "Order and order item transactional processing",
        "Normalized Relational Database Schema & ERD architecture",
        "Interactive Java GUI interface connected via MariaDB JDBC driver"
      ],
      schemaBreakdown: [
        { table: "customers", cols: "customer_id (PK), name, contact_info, address" },
        { table: "furniture_items", cols: "item_id (PK), name, category, unit_price, stock_qty" },
        { table: "orders", cols: "order_id (PK), customer_id (FK), order_date, total_amount, status" },
        { table: "order_items", cols: "order_item_id (PK), order_id (FK), item_id (FK), quantity, unit_price" }
      ],
      githubUrl: "https://github.com/[YOUR_GITHUB_USERNAME]/prottoy-furniture",
      demoUrl: null
    },
    {
      id: "gui-database-project",
      number: "02",
      title: "GUI Database Project",
      category: "GUI / Database",
      status: "Completed",
      statusBadgeClass: "badge-emerald",
      technologies: ["Python", "SQL", "GUI Architecture"],
      description: "A GUI-based database application developed as part of software engineering and database systems learning, emphasizing user interaction, data validation, and clean database operations.",
      highlights: [
        "Interactive graphical user interface for relational operations",
        "Input validation and safe query execution",
        "Practical integration of database logic with frontend controls"
      ],
      schemaBreakdown: [
        { table: "data_records", cols: "record_id (PK), title, details, timestamp, status" },
        { table: "categories", cols: "category_id (PK), category_name, description" }
      ],
      githubUrl: "https://github.com/[YOUR_GITHUB_USERNAME]/gui-database-project",
      demoUrl: null
    },
    {
      id: "student-management-app",
      number: "03",
      title: "Student Management App",
      category: "Mobile Application",
      status: "Upcoming / In Progress",
      statusBadgeClass: "badge-amber",
      technologies: ["Flutter / Dart or React Native", "Mobile UI", "Local Storage"],
      description: "A planned real-world student management application focused on delivering clean, student-oriented utility through a modern, responsive mobile interface.",
      highlights: [
        "Academic task tracking and milestone reminders",
        "Course schedule and semester planner",
        "Clean mobile UX optimized for touch interactions"
      ],
      schemaBreakdown: [
        { table: "students", cols: "student_id, roll_no, semester, major, batch" },
        { table: "courses", cols: "course_code, title, credits, schedule" }
      ],
      githubUrl: "https://github.com/[YOUR_GITHUB_USERNAME]/student-management-app",
      demoUrl: null
    }
  ],

  problemSolving: {
    headline: "PROBLEM SOLVING IS HOW I THINK.",
    problemsSolved: "200+",
    platform: "Codeforces",
    status: "Programming Contest Participant",
    codeforcesProfileUrl: "https://codeforces.com/profile/[YOUR_CODEFORCES_HANDLE]",
    ratingPlaceholder: "Active Contestant",
    topics: [
      "Binary Search",
      "Sliding Window",
      "Binary Trees & BST",
      "AVL Trees & Heaps",
      "Stack & Queue Traversals",
      "Map & Frequency Counting"
    ]
  },

  achievements: [
    {
      title: "200+ Programming Problems Solved",
      category: "Algorithmic Mastery",
      description: "Dedicated problem solving across competitive programming platforms, strengthening analytical thinking, algorithmic efficiency, and edge-case handling.",
      meta: "Continuous Practice • Data Structures & Algorithms"
    },
    {
      title: "Codeforces Contest Participation",
      category: "Competitive Programming",
      description: "Active participant in timed Codeforces programming contests, practicing speed, algorithmic synthesis, and optimal time complexity under constraints.",
      meta: "Codeforces Rounds • Algorithmic Contests"
    },
    {
      title: "IMU PC Contest Certificate",
      category: "University Contest",
      description: "Earned official participation certificate in the Intra-Metropolitan University Programming Contest (IMU PC), competing alongside software engineering peers.",
      meta: "Metropolitan University • Programming Contest"
    },
    {
      title: "SWE Intra Futsal Tournament Season 02",
      category: "Athletics & Community",
      description: "Represented team SWE 8th Stellars in the Software Engineering Department Intra Futsal Tournament, championing team communication, synergy, and sportsmanship.",
      meta: "Team: SWE 8th Stellars • Season 02"
    }
  ],

  education: {
    institution: "Metropolitan University",
    degree: "B.Sc. (Hons) in Software Engineering",
    duration: "2025 — 2029",
    currentYearSemester: "2nd Year • 3rd Semester",
    expectedGraduation: "2029",
    location: "Bangladesh",
    keyAreas: [
      "Object-Oriented Programming (Java / C++)",
      "Data Structures & Algorithm Design",
      "Relational Database Management Systems & SQL",
      "Discrete Mathematics & Computation",
      "Software Engineering Methodologies"
    ]
  },

  currentlyLearning: [
    {
      title: "Flutter & Dart",
      badge: "Mobile Dev",
      description: "Learning widget trees, declarative UI patterns, cross-platform compilation, and clean state management for mobile apps."
    },
    {
      title: "React Native",
      badge: "Cross-Platform",
      description: "Exploring component-driven mobile development, flexbox mobile layouts, and JavaScript bridge architectures."
    },
    {
      title: "Mobile Application Development",
      badge: "Core Focus",
      description: "Studying native mobile paradigms, device storage, user experience design, and touch gestures."
    },
    {
      title: "Backend Fundamentals",
      badge: "Architecture",
      description: "Investigating REST principles, server routing, and database communication beyond JDBC."
    },
    {
      title: "Software Architecture",
      badge: "Engineering",
      description: "Exploring modularity, clean architecture layers (UI, Logic, Data), and maintainable system design."
    },
    {
      title: "Real-World App Development",
      badge: "Product Focus",
      description: "Applying software engineering theories to build practical, problem-solving software for real users."
    }
  ]
};
