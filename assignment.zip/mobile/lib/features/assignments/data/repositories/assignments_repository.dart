import '../../../../core/network/api_client.dart';
import '../../../../core/network/api_endpoints.dart';
import '../../../../core/storage/cache_manager.dart';
import '../models/assignment_model.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../auth/presentation/controllers/auth_controller.dart';

class AssignmentsRepository {
  final ApiClient _apiClient;

  AssignmentsRepository(this._apiClient);

  Future<List<AssignmentModel>> getAssignments({
    String? courseId,
    String? status,
    String? priority,
    String? search,
    String? sortBy,
    String? sortOrder,
  }) async {
    try {
      final response = await _apiClient.get(
        ApiEndpoints.assignments,
        queryParameters: {
          if (courseId != null) 'courseId': courseId,
          if (status != null) 'status': status,
          if (priority != null) 'priority': priority,
          if (search != null) 'search': search,
          if (sortBy != null) 'sortBy': sortBy,
          if (sortOrder != null) 'sortOrder': sortOrder,
        },
      );

      final list = (response as List<dynamic>).map((e) => AssignmentModel.fromJson(e as Map<String, dynamic>)).toList();
      await CacheManager.setJson('cached_assignments', response);
      return list;
    } catch (e) {
      final cached = CacheManager.getJson('cached_assignments');
      if (cached != null && cached is List) {
        return cached.map((e) => AssignmentModel.fromJson(e as Map<String, dynamic>)).toList();
      }
      rethrow;
    }
  }

  Future<AssignmentModel> createAssignment({
    required String courseId,
    required String title,
    String? description,
    required DateTime dueDate,
    String priority = 'MEDIUM',
    String status = 'PENDING',
    String? attachmentUrl,
  }) async {
    final response = await _apiClient.post(
      ApiEndpoints.assignments,
      data: {
        'courseId': courseId,
        'title': title.trim(),
        if (description != null) 'description': description.trim(),
        'dueDate': dueDate.toIso8601String(),
        'priority': priority,
        'status': status,
        if (attachmentUrl != null) 'attachmentUrl': attachmentUrl.trim(),
      },
    );
    return AssignmentModel.fromJson(response as Map<String, dynamic>);
  }

  Future<void> updateStatus(String id, String status) async {
    await _apiClient.patch(ApiEndpoints.assignmentStatus(id), data: {'status': status});
  }

  Future<void> deleteAssignment(String id) async {
    await _apiClient.delete(ApiEndpoints.assignmentDetail(id));
  }
}

final assignmentsRepositoryProvider = Provider<AssignmentsRepository>((ref) {
  final apiClient = ref.watch(apiClientProvider);
  return AssignmentsRepository(apiClient);
});

class AssignmentsController extends StateNotifier<AsyncValue<List<AssignmentModel>>> {
  final AssignmentsRepository _repository;
  String? _selectedStatus;
  String? _selectedCourseId;

  AssignmentsController(this._repository) : super(const AsyncValue.loading()) {
    loadAssignments();
  }

  Future<void> loadAssignments() async {
    state = const AsyncValue.loading();
    try {
      final items = await _repository.getAssignments(
        status: _selectedStatus,
        courseId: _selectedCourseId,
      );
      state = AsyncValue.data(items);
    } catch (e, stack) {
      state = AsyncValue.error(e, stack);
    }
  }

  void filterByStatus(String? status) {
    _selectedStatus = status;
    loadAssignments();
  }

  void filterByCourse(String? courseId) {
    _selectedCourseId = courseId;
    loadAssignments();
  }

  Future<bool> toggleComplete(AssignmentModel assignment) async {
    final newStatus = assignment.status == 'COMPLETED' ? 'PENDING' : 'COMPLETED';
    try {
      await _repository.updateStatus(assignment.id, newStatus);
      await loadAssignments();
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> deleteAssignment(String id) async {
    try {
      await _repository.deleteAssignment(id);
      await loadAssignments();
      return true;
    } catch (e) {
      return false;
    }
  }
}

final assignmentsControllerProvider =
    StateNotifierProvider<AssignmentsController, AsyncValue<List<AssignmentModel>>>((ref) {
  final repo = ref.watch(assignmentsRepositoryProvider);
  return AssignmentsController(repo);
});
