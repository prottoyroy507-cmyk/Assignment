class AssignmentCourseInfo {
  final String id;
  final String code;
  final String name;
  final String colorHex;

  const AssignmentCourseInfo({
    required this.id,
    required this.code,
    required this.name,
    required this.colorHex,
  });

  factory AssignmentCourseInfo.fromJson(Map<String, dynamic> json) {
    return AssignmentCourseInfo(
      id: json['id'] as String? ?? '',
      code: json['code'] as String? ?? '',
      name: json['name'] as String? ?? '',
      colorHex: json['colorHex'] as String? ?? '#2563EB',
    );
  }
}

class AssignmentModel {
  final String id;
  final String courseId;
  final String title;
  final String? description;
  final DateTime dueDate;
  final String priority; // LOW, MEDIUM, HIGH
  final String status; // PENDING, IN_PROGRESS, COMPLETED
  final String? attachmentUrl;
  final bool isOverdue;
  final AssignmentCourseInfo? course;

  const AssignmentModel({
    required this.id,
    required this.courseId,
    required this.title,
    this.description,
    required this.dueDate,
    required this.priority,
    required this.status,
    this.attachmentUrl,
    this.isOverdue = false,
    this.course,
  });

  factory AssignmentModel.fromJson(Map<String, dynamic> json) {
    final dueDate = DateTime.parse(json['dueDate']);
    final isCompleted = json['status'] == 'COMPLETED';
    final overdue = json['isOverdue'] as bool? ?? (!isCompleted && dueDate.isBefore(DateTime.now()));

    return AssignmentModel(
      id: json['id'] as String,
      courseId: json['courseId'] as String,
      title: json['title'] as String,
      description: json['description'] as String?,
      dueDate: dueDate,
      priority: json['priority'] as String? ?? 'MEDIUM',
      status: json['status'] as String? ?? 'PENDING',
      attachmentUrl: json['attachmentUrl'] as String?,
      isOverdue: overdue,
      course: json['course'] != null ? AssignmentCourseInfo.fromJson(json['course'] as Map<String, dynamic>) : null,
    );
  }

  AssignmentModel copyWith({
    String? title,
    String? description,
    DateTime? dueDate,
    String? priority,
    String? status,
    String? attachmentUrl,
    bool? isOverdue,
  }) {
    return AssignmentModel(
      id: id,
      courseId: courseId,
      title: title ?? this.title,
      description: description ?? this.description,
      dueDate: dueDate ?? this.dueDate,
      priority: priority ?? this.priority,
      status: status ?? this.status,
      attachmentUrl: attachmentUrl ?? this.attachmentUrl,
      isOverdue: isOverdue ?? this.isOverdue,
      course: course,
    );
  }
}
